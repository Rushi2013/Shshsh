import React, { useState } from 'react';
import { 
  ArrowLeft, Bell, Moon, Search, MessageCircle, ExternalLink, 
  Heart, ArrowRight, ChevronDown, Copy, Users
} from 'lucide-react';

type AppData = {
  id: string;
  name: string;
  desc: string;
  logo: React.ReactNode;
  tag?: string;
};

export default function App() {
  const [activeIframe, setActiveIframe] = useState<string | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  const apps: AppData[] = [
    {
      id: 'allen',
      name: 'ALLEN',
      desc: 'ALLEN Career Institute courses, lectures and test material — opens fully inside PrepPro Network.',
      logo: (
        <div className="w-16 h-16 rounded-full border-[3px] border-amber-400 bg-white flex items-center justify-center shadow-sm shrink-0">
          <span className="text-[#002f6c] font-black text-xs tracking-tighter">ALLEN</span>
        </div>
      )
    },
    {
      id: 'pw',
      name: 'PHYSICS WALLAH',
      desc: 'Access Physics Wallah premium courses and study materials with enhanced features.',
      logo: (
        <div className="w-16 h-16 rounded-full bg-black border-[3px] border-slate-200 flex flex-col items-center justify-center shadow-sm shrink-0 font-serif">
          <span className="text-white text-[18px] leading-[0.8] tracking-widest translate-x-1">P</span>
          <span className="text-white text-[22px] leading-[0.8]">W</span>
        </div>
      )
    },
    {
      id: 'next',
      name: 'NEXT TOPPERS',
      desc: 'Learn from toppers and get insider tips for cracking competitive exams.',
      logo: (
        <div className="w-16 h-16 rounded-full bg-[#1b4341] flex flex-col items-center justify-center shadow-sm shrink-0">
          <div className="flex text-[#38b2ac]">
            <ChevronDown className="w-8 h-8 -rotate-90 -mr-4" />
            <ChevronDown className="w-8 h-8 -rotate-90" />
          </div>
        </div>
      )
    },
    {
      id: 'unacademy',
      name: 'UNACADEMY',
      desc: 'Access Unacademy courses and study materials for various competitive exams.',
      tag: 'Access Code: PUSHPARAJ',
      logo: (
        <div className="w-16 h-16 rounded-full bg-white border border-slate-200 flex items-center justify-center shadow-sm shrink-0">
          <div className="w-8 h-8 bg-black rounded-full rounded-tr-none rotate-45 transform" />
        </div>
      )
    },
    {
      id: 'vibrant',
      name: 'VIBRANT ACADEMY',
      desc: 'Vibrant Academy premium content for JEE & competitive exam preparation.',
      logo: (
        <div className="w-16 h-16 rounded-full bg-[#fdf5e6] border-[3px] border-red-500 flex items-center justify-center shadow-sm shrink-0 relative overflow-hidden">
           <div className="text-red-600 font-bold text-3xl">V</div>
           <div className="absolute inset-0 flex items-center justify-center text-amber-500/50 text-5xl font-light">X</div>
        </div>
      )
    }
  ];

  if (activeIframe) {
    return (
      <div className="h-screen w-screen flex flex-col bg-slate-100 overflow-hidden">
        <div className="h-14 border-b border-slate-200 bg-slate-50 flex items-center px-4 shrink-0 shadow-sm z-10">
          <button 
            onClick={() => setActiveIframe(null)}
            className="flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-indigo-600 transition-colors bg-white border border-slate-200 hover:bg-slate-50 px-3 py-1.5 rounded-md shadow-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Apps List
          </button>
          <div className="ml-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-xs font-medium text-slate-500">Connected securely via PrepPro Network</span>
          </div>
        </div>
        <iframe 
          src={activeIframe} 
          className="flex-1 w-full h-full border-none bg-white"
          title="App Embed"
          allowFullScreen
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white text-slate-800 font-sans selection:bg-indigo-100 pb-20">
      {/* Auth Modal */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="p-6 sm:p-8 flex-1">
              <div className="flex justify-between items-center mb-6">
                <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-md">
                  <span className="text-white font-bold text-2xl">P</span>
                </div>
                <button 
                  onClick={() => setShowAuthModal(false)}
                  className="w-8 h-8 flex items-center justify-center rounded-full text-slate-400 hover:bg-slate-100 transition-colors"
                >
                  <span className="text-xl leading-none">&times;</span>
                </button>
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-1">
                {authMode === 'login' ? 'Welcome back' : 'Create an account'}
              </h2>
              <p className="text-slate-500 text-sm mb-6">
                {authMode === 'login' 
                  ? 'Enter your details to access your dashboard.' 
                  : 'Join PrepPro Network and prep like a pro.'}
              </p>
              
              <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                {authMode === 'register' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">Full Name</label>
                    <input 
                      type="text" 
                      placeholder="Rahul Kumar"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-sm font-medium transition-all"
                    />
                  </div>
                )}
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">Email Address</label>
                  <input 
                    type="email" 
                    placeholder="you@example.com"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-sm font-medium transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1.5 uppercase tracking-wide">Password</label>
                  <input 
                    type="password" 
                    placeholder="••••••••"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-sm font-medium transition-all"
                  />
                </div>
                <button className="w-full bg-indigo-600 text-white font-semibold rounded-xl py-3.5 hover:bg-indigo-700 transition-colors shadow-sm mt-2">
                  {authMode === 'login' ? 'Sign In' : 'Sign Up'}
                </button>
              </form>
              
              <div className="mt-6 text-center text-sm font-medium text-slate-500">
                {authMode === 'login' ? (
                  <p>Don't have an account? <button onClick={() => setAuthMode('register')} className="text-indigo-600 hover:underline">Sign up</button></p>
                ) : (
                  <p>Already have an account? <button onClick={() => setAuthMode('login')} className="text-indigo-600 hover:underline">Sign in</button></p>
                )}
              </div>
            </div>
            <div className="bg-slate-50 p-4 text-center border-t border-slate-100">
              <p className="text-xs text-slate-400">By continuing, you agree to our Terms of Service and Privacy Policy.</p>
            </div>
          </div>
        </div>
      )}

      {/* Navbar */}
      <nav className="h-16 border-b border-slate-100 flex items-center justify-between px-6 sm:px-8 bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="flex items-center gap-3 cursor-pointer">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shrink-0 shadow-sm">
            <span className="text-white font-bold text-xl">P</span>
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-800 hidden sm:block">PrepPro<span className="text-indigo-600">Network</span></span>
        </div>
        
        <div className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-500">
          {['Dashboard', 'Library', 'Live Classes', 'Batches'].map((item) => (
            <button
              key={item}
              className={`transition-colors ${
                item === 'Dashboard' 
                  ? 'font-semibold text-slate-900' 
                  : 'hover:text-indigo-600'
              }`}
            >
              {item}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <button className="p-2 hover:bg-slate-100 rounded-full text-slate-400 transition-colors hidden sm:block">
            <Bell className="w-5 h-5" />
          </button>
          <button 
            onClick={() => {
              setAuthMode('login');
              setShowAuthModal(true);
            }}
            className="bg-slate-900 hover:bg-slate-800 text-white px-5 py-2 rounded-lg text-sm font-semibold transition-colors shadow-sm"
          >
            Sign In
          </button>
        </div>
      </nav>

      <main className="max-w-[1000px] mx-auto px-6 pt-10">
        {/* Back button */}
        <button className="flex items-center gap-2 text-sm font-bold text-slate-800 hover:text-indigo-600 transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </button>
        
        {/* Header content */}
        <div className="mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md border border-indigo-100 bg-indigo-50/50 text-indigo-600 text-[11px] font-bold tracking-[0.2em] mb-6 uppercase">
            <span className="w-2.5 h-3.5 border-2 border-indigo-400 rounded-sm block"></span>
            PREPPRO STUDY APPS
          </div>
          
          <h1 className="text-5xl sm:text-[80px] font-black text-slate-800 leading-[0.95] tracking-tight mb-6">
            THE ONLY <br />
            <span className="text-indigo-600">APPS</span> YOU NEED.
          </h1>
          
          <p className="text-lg text-slate-500 font-medium">
            Hand-picked premium coaching platforms — tap to launch, free forever.
          </p>
        </div>

        {/* Featured Portal Card */}
        <div className="bg-gradient-to-br from-indigo-600 to-violet-700 rounded-[2rem] p-6 sm:p-8 flex items-center justify-between mb-10 cursor-pointer shadow-xl shadow-indigo-200/50 group">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/10 flex items-center justify-center border border-white/20 shadow-sm backdrop-blur-sm group-hover:scale-105 transition-transform shrink-0">
               <span className="text-white font-bold text-3xl">P</span>
            </div>
            <div>
              <div className="flex items-center gap-3 mb-1.5 flex-wrap">
                <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">PrepPro Network Portal</h3>
                <span className="bg-white/20 text-white text-[11px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1.5 backdrop-blur-sm">
                  <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                  Live Portal
                </span>
              </div>
              <p className="text-indigo-100 font-medium text-sm sm:text-base">All Study Portals — One Place</p>
              <p className="text-indigo-200/80 text-sm mt-1 hidden sm:block">PW, Vibrant, Next Toppers & all portals in one place</p>
            </div>
          </div>
          <div className="p-3 bg-white/10 rounded-xl border border-white/10 group-hover:bg-white/20 transition-colors shrink-0 hidden sm:block">
            <ExternalLink className="w-6 h-6 text-white" />
          </div>
        </div>

        {/* Search Bar */}
        <div className="max-w-[600px] mx-auto mb-10 relative">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-slate-400" />
          </div>
          <input 
            type="text"
            placeholder="Search apps..."
            className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-sm font-medium transition-all shadow-sm"
          />
        </div>

        {/* WhatsApp Banner */}
        <div className="bg-emerald-50/50 border border-emerald-100 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-14 cursor-pointer hover:shadow-md transition-all group">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-emerald-500 rounded-xl flex items-center justify-center text-white shadow-sm shrink-0 group-hover:scale-105 transition-transform">
              <MessageCircle className="w-7 h-7 fill-white" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded uppercase tracking-wide">JOIN REQUEST</span>
                <span className="text-[11px] font-semibold text-emerald-600 flex items-center gap-1">
                  <Users className="w-3.5 h-3.5" /> Free
                </span>
              </div>
              <h3 className="font-bold text-slate-800 text-lg">WhatsApp Channel — Study Apps Updates</h3>
              <p className="text-sm font-medium text-slate-500 mt-0.5">Tap to follow PrepPro Network on WhatsApp for instant updates.</p>
            </div>
          </div>
          <button className="bg-emerald-500 text-white px-5 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-1.5 hover:bg-emerald-600 transition-colors shadow-sm shrink-0">
            Join <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Apps List */}
        <div className="flex flex-col gap-3 mb-12">
          {apps.map((app, index) => (
            <div 
              key={app.id} 
              onClick={() => {
                if (app.id === 'pw') {
                  setActiveIframe('https://nexthope.pages.dev/pw/');
                } else {
                  // Standard interaction demo for others
                  console.log(`Clicked ${app.name}`);
                }
              }}
              className="flex items-start sm:items-center gap-4 sm:gap-6 p-4 sm:py-5 sm:px-5 border border-slate-100 bg-white hover:border-indigo-100 hover:shadow-lg hover:shadow-indigo-50/50 transition-all cursor-pointer rounded-2xl group"
            >
              <span className="text-slate-300 font-semibold text-sm w-6 shrink-0 mt-3 sm:mt-0">
                {String(index + 1).padStart(2, '0')}
              </span>
              
              {app.logo}
              
              <div className="flex-1 mt-1 sm:mt-0">
                <h3 className="text-xl font-bold text-slate-800 tracking-tight group-hover:text-indigo-600 transition-colors">{app.name}</h3>
                <p className="text-slate-500 font-medium text-sm mt-0.5 leading-relaxed pr-4">{app.desc}</p>
                {app.tag && (
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-indigo-50 text-indigo-600 border border-indigo-100 rounded-md text-xs font-semibold mt-3">
                    <Copy className="w-3.5 h-3.5" />
                    {app.tag}
                  </div>
                )}
              </div>
              
              <div className="flex items-center gap-3 shrink-0 mt-3 sm:mt-0">
                <button 
                  className="text-slate-400 hover:text-rose-500 transition-colors p-2 rounded-full hover:bg-rose-50"
                  onClick={(e) => {
                    e.stopPropagation();
                  }}
                >
                  <Heart className="w-5 h-5" />
                </button>
                <button 
                  className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50 transition-colors bg-white shadow-sm"
                  onClick={(e) => {
                    e.stopPropagation();
                  }}
                >
                  <MessageCircle className="w-4 h-4" />
                  Channel
                </button>
                <div className="p-2 text-slate-400 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all hidden sm:block">
                  <ArrowRight className="w-5 h-5" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Get More Apps Button */}
        <div className="flex justify-center">
          <button className="flex items-center gap-2 px-6 py-3 rounded-xl border border-slate-200 bg-white font-semibold text-slate-600 shadow-sm hover:bg-slate-50 hover:text-slate-900 transition-all">
            <ChevronDown className="w-5 h-5" />
            Get More Apps (12+)
          </button>
        </div>
      </main>
    </div>
  );
}
